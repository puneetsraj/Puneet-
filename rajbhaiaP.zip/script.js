function generateUserId() {
  return 'USER' + Math.floor(100000 + Math.random() * 900000);
}

document.getElementById('signup-form')?.addEventListener('submit', function (e) {
  e.preventDefault();
  const name = document.getElementById('signup-name').value;
  const mobile = document.getElementById('signup-mobile').value;
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;

  const userId = generateUserId();
  const user = { userId, name, mobile, email, password };
  localStorage.setItem(userId, JSON.stringify(user));

  alert(`Your User ID is: ${userId}. Please log in.`);
  window.location.href = 'index.html';
});

document.getElementById('login-form')?.addEventListener('submit', function (e) {
  e.preventDefault();
  const userId = document.getElementById('login-user-id').value;
  const password = document.getElementById('login-password').value;

  const user = JSON.parse(localStorage.getItem(userId));
  if (user && user.password === password) {
    localStorage.setItem('loggedInUser', userId);
    window.location.href = 'home.html';
  } else {
    alert('Invalid User ID or Password.');
  }
});

document.getElementById('forget password.html')?.addEventListener('submit', function (e) {
  e.preventDefault();
  const email = document.getElementById('reset-email').value;
  alert('Password reset instructions sent to ' + email);
});
/* General Styles */
body {
  margin: 0;
  font-family: 'Arial', sans-serif;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(to right, #1c1c1c, #4b4b4b); /* Black Gradient */
  color: white;
}

.home-container {
  width: 90%;
  max-width: 1000px;
  background: rgba(0, 0, 0, 0.8); /* Semi-transparent black */
  padding: 20px;
  border-radius: 15px;
  text-align: center;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.6);
  position: relative;
  overflow: hidden;
}

.profile-icon {
  position: absolute;
  top: 10px;
  right: 20px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
}

.profile-icon img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* Header Section */
.home-header h1 {
  font-size: 2rem;
  margin-bottom: 10px;
  color: #fff;
}

.home-header p {
  font-size: 1rem;
  margin: 10px 0;
}

.home-header button {
  padding: 10px 20px;
  background: linear-gradient(to right, #56ab2f, #a8e063);
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.home-header button:hover {
  background: linear-gradient(to right, #a8e063, #56ab2f);
}

.home-header .active {
  color: green;
}

.home-header .inactive {
  color: red;
}

.home-main {
  margin-top: 30px;
}

.dashboard {
  display: flex;
  flex-wrap: nowrap; /* Prevent wrapping */
  gap: 20px;
  justify-content: flex-start;
  overflow-x: auto; /* Enables horizontal scrolling */
  padding-bottom: 20px;
}

.card {
  background: linear-gradient(to top left, #43cea2, #185a9d);
  color: white;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
  text-align: center;
  flex: 0 0 auto; /* Prevent stretching */
  min-width: 250px;
  margin-top: 10px;
  transition: transform 0.3s ease-in-out;
}

.card:hover {
  transform: scale(1.05); /* Hover effect for cards */
}

.card h3 {
  font-size: 1.5rem;
  margin-bottom: 10px;
}

.card p {
  font-size: 1rem;
  margin: 15px 0;
}

.card button {
  padding: 10px 20px;
  background: #fff;
  color: #333;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.card button:hover {
  background: #56ab2f;
  color: white;
}

/* Responsive Design */
@media (max-width: 600px) {
  .home-container {
    padding: 15px;
  }

  .dashboard {
    flex-direction: column; /* Stacks cards vertically on smaller screens */
    gap: 10px;
    padding-bottom: 0;
  }

  .card {
    width: 100%; /* Full width for smaller screens */
  }
}
// Load Sponsor ID automatically from localStorage
document.addEventListener('DOMContentLoaded', function () {
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    if (currentUser && currentUser.email) {
        document.getElementById('sponsorId').value = currentUser.email;
    }
});

// Handle Referral Form Submission
document.getElementById('referralForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const sponsorId = document.getElementById('sponsorId').value;
    const newUserEmail = document.getElementById('newUserEmail').value;

    if (!sponsorId || !newUserEmail) {
        alert('Please provide valid information!');
        return;
    }

    // Save referral data to localStorage
    const referrals = JSON.parse(localStorage.getItem('referrals')) || [];
    referrals.push({ sponsorId, newUserEmail });

    localStorage.setItem('referrals', JSON.stringify(referrals));

    // Update Level Display
    updateLevelDetails(referrals);

    alert('Referral added successfully!');
    document.getElementById('newUserEmail').value = ''; // Clear the input
});

// Update Level Details Display
function updateLevelDetails(referrals) {
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));
    const sponsorId = currentUser ? currentUser.email : '';
    const userLevel = referrals.filter(ref => ref.sponsorId === sponsorId);

    const levelDetails = userLevel.map((ref, index) => 
        `<p>${index + 1}. ${ref.newUserEmail}</p>`).join('');

    document.getElementById('levelDetails').innerHTML = levelDetails || 'No referrals yet.';
}

// Load Level Details on Page Load
document.addEventListener('DOMContentLoaded', function () {
    const referrals = JSON.parse(localStorage.getItem('referrals')) || [];
    updateLevelDetails(referrals);
});
document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Get values from sign-up form
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var mobile = document.getElementById('mobile').value;
    var password = document.getElementById('password').value;

    // Get Sponsor ID from URL parameter (if exists)
    var urlParams = new URLSearchParams(window.location.search);
    var sponsorID = urlParams.get('sponsorID') || document.getElementById('sponsorID').value;

    // Create user object
    var userData = {
        name: name,
        email: email,
        mobile: mobile,
        password: password,
        sponsorID: sponsorID // Save Sponsor ID
    };

    // Save each user's data with a unique key (using email as the key)
    localStorage.setItem(email, JSON.stringify(userData));

    alert('User data saved successfully!');
});
// Get modal and button elements
var modal = document.getElementById("referralModal");
var btn = document.getElementById("referralBtn");
var span = document.getElementsByClassName("close-btn")[0];

// Open the modal when referral button is clicked
btn.onclick = function() {
    modal.style.display = "block";
}

// Close the modal when close button is clicked
span.onclick = function() {
    modal.style.display = "none";
}

// Close the modal if user clicks anywhere outside the modal
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Handle referral form submission
document.getElementById("referForm").addEventListener("submit", function(event) {
    event.preventDefault();

    var referEmail = document.getElementById("referEmail").value;
    var referralId = document.getElementById("userReferralId").innerText;

    // Handle referral logic (e.g., save to localStorage or send to server)
    alert("Referral made successfully! Referral Email: " + referEmail + ", Your Referral ID: " + referralId);

    // Close modal after referral
    modal.style.display = "none";
});
